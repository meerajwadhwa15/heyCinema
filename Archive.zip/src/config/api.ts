const API_KEY = '17a520ef';
const DOMAIN = 'http://www.omdbapi.com';
export const SEARCH_MOVIES = `${DOMAIN}/?apikey=${API_KEY}`;
