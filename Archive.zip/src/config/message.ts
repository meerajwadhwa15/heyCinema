export const ERROR_MESSAGE = 'Oops, Some Error Ocurred. Please try again.'
