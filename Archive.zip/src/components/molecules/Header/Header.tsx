import React, { FunctionComponent } from 'react';
import './style.css';

export type Props = {};

const Header: FunctionComponent<Props> = props => <header>hey Cinema</header>;

export default Header;
