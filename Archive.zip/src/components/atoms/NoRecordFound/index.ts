export { default } from './NoRecordFound'
